filename = 'positiveExample.bmp';
A=imread(filename,'bmp');
A = double(A)
R = A(:,:,1);
G = A(:,:,2);
B = A(:,:,3);

figure(1);
histogramR = histogram(R,0,255,256);
plot(histogramR);

figure(2);
histogramG = histogram(G,0,255,256);
plot(histogramG);

figure(3);
histogramB = histogram(B,0,255,256);
plot(histogramB);


filename = 'negativeExample.bmp';
A=imread(filename,'bmp');
A = double(A)
R = A(:,:,1);
G = A(:,:,2);
B = A(:,:,3);

figure(4);
histogramR = histogram(R,0,255,256);
plot(histogramR);

figure(5);
histogramG = histogram(G,0,255,256);
plot(histogramG);

figure(6);
histogramB = histogram(B,0,255,256);
plot(histogramB);
