filename = 'positiveExample.bmp';
A=imread(filename,'bmp');
HSV = rgb2hsv(A);
H = HSV(:,:,1);
S = HSV(:,:,2);
V = HSV(:,:,3);

figure(1);
histogramH = histogram(H,0,1,100);
plot(histogramH);

figure(2);
histogramS = histogram(S,0,1,100);
plot(histogramS);

figure(3);
histogramV = histogram(V,0,1,100);
plot(histogramV);


filename = 'negativeExample.bmp';
A=imread(filename,'bmp');
HSV = rgb2hsv(A);
H = HSV(:,:,1);
S = HSV(:,:,2);
V = HSV(:,:,3);

figure(4);
histogramH = histogram(H,0,1,100);
plot(histogramH);

figure(5);
histogramS = histogram(S,0,1,100);
plot(histogramS);

figure(6);
histogramV = histogram(V,0,1,100);
plot(histogramV);