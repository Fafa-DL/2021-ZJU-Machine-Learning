function X = histogram(A,lowerBound,upperBound,numOfBins);
[M,N] = size(A);
X = zeros(1,numOfBins);
for i=1:M
    for j= 1:N
        s = floor(numOfBins*(A(i,j)-lowerBound)/(upperBound-lowerBound))+1;
        s = min(s,numOfBins);
        X(s) = X(s)+1;
    end;
end;
X = X/sum(X);